"""Convenience imports for the shortlist module."""
from .shortlist import (
    DEFAULT_CONFIG,
    DEFAULT_CONFIG_PATH,
    generate_shortlist,
    load_config,
)
